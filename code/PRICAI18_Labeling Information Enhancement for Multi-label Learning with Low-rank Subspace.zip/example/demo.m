clc
clear
addpath(genpath(pwd));
a={'CAL500'};
% beg={'Dataset/'}; % for mac
beg={'Dataset\'}; % for windows
%%
for dataN = 1:1
     for k=1:10
%         T=strcat(beg(1),a(dataN),'/',a(dataN),'_total_',num2str(k),'.mat'); % for mac
        T=strcat(beg(1),a(dataN),'\',a(dataN),'_total_',num2str(k),'.mat'); % for windows
        load(T{1,1});
        
        %% Label Enhancement
        
        % The training part of LE algorithm.
        tic;
        train_Y=train_target;
        UnitMatrix=ones(1,size(train_data,1));%1xn
        train_X=[train_data';UnitMatrix];%[X;1] (d+1)xn
        W=eye(size(train_Y,1),size(train_X,1));%initial W (tx(d+1)) train_target(Y) txn
        train_Y_0=W*train_X;
        Z=[train_Y_0;train_X];
        eta=0.25;
        lenda=0.1;
        miu=initial_miu(eta,Z);
         
        % The function of LE provides a target function and the gradient.
        tauZ=min([3.8*size(train_Y,1)*size(train_Y,2)/lenda,(size(train_X)-1)*size(train_X,2)]);
        Step=1e-5;
        save dt.mat miu lenda tauZ Z train_Y train_X UnitMatrix Step;
        [Z]=le_process();
        fprintf('Training time of LE: %8.7f s\n', toc);
        
        train_Y_1 = Z(1:size(train_Y,1),:);
%         enhancementFile = strcat(beg(1),a(dataN),'/',a(dataN),'_enhancement_',num2str(k),'.mat'); % for mac
        enhancementFile = strcat(beg(1),a(dataN),'\',a(dataN),'_enhancement_',num2str(k),'.mat'); % for windows
        save(enhancementFile{1,1},'train_Y_1','train_data') ;

        %% Predictive Model Induction
        
        % model building
        para.tol  = 1e-5; %tolerance during the iteration
        para.epsi = 0.001; %instances whose distance computed is more than epsi should be penalized
        para.C1   = 1; %penalty parameter
        para.C2   = 0.1; %penalty parameter
        para.ker  = 'rbf'; %type of kernel function ('lin', 'poly', 'rbf', 'sam')
        para.par  = 1*mean(pdist(train_data)); %parameter of kernel function

        model = amsvr(train_data, train_Y_1', para);

        % Prediction
        [label, degree] = predict(test_data, train_data, model);
        fprintf('Finish prediction of LIEML:. \n');
%         predictionFile = strcat(beg(1),a(dataN),'/',a(dataN),'_prediction_',num2str(k),'.mat'); % for mac
        predictionFile = strcat(beg(1),a(dataN),'\',a(dataN),'_prediction_',num2str(k),'.mat'); % for windows
        save(predictionFile{1,1},'label','degree') ;

        %% Evaluation

        [rankingLoss, oneError,hammingLoss, coverage, averagePrecision] = MLEvaluate( degree', label',test_target );
        result(:,k)=[ rankingLoss; oneError;hammingLoss; coverage; averagePrecision ];
        EvaluateResult=[ rankingLoss; oneError; hammingLoss;coverage; averagePrecision ];
%         EvaluateResultFile = strcat(beg(1),a(dataN),'/',a(dataN),'_EvaluateResult_',num2str(k),'.mat'); % for mac
        EvaluateResultFile = strcat(beg(1),a(dataN),'\',a(dataN),'_EvaluateResult_',num2str(k),'.mat'); % for windows
        save(EvaluateResultFile{1,1},'EvaluateResult') ;
%         parameterFile = strcat(beg(1),a(dataN),'/',a(dataN),'_parameter_',num2str(k),'.mat'); % for mac
        parameterFile = strcat(beg(1),a(dataN),'\',a(dataN),'_parameter_',num2str(k),'.mat'); % for windows
        save(parameterFile{1,1},'eta','miu','Step','tauZ','para') ;
        
    end
 
    %% Final results over 10 folds
    mean_result=mean(result');
    std_result=std(result');
    T_result={'';'';'';''};
    for i=1:size(result,1)
        T_result{i}=strcat(num2str(mean_result(i)),'��',num2str(std_result(i)));
    end
%     resultFile = strcat(beg(1),a(dataN),'/',a(dataN),'_result','.mat'); % for mac
    resultFile = strcat(beg(1),a(dataN),'\',a(dataN),'_result','.mat'); % for windows
    save(resultFile{1,1},'mean_result','T_result') ;
end
%%