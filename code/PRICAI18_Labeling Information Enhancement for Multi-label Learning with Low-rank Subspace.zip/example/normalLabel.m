function [ normalizedLabel ] = normalLabel( label )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[size_sam,size_Y] = size(label);
for i = 1:size_sam
    miny = min(label(i,:));
    if miny < 0; 
        label(i,:) = label(i,:) - 1.01*miny;
    end
end
sumLabel = sum(label,2);
if sumLabel ~= 0
    normalizedLabel = label./repmat(sumLabel,[1,size_Y]);
else
    normalizedLabel = label;
end

end

