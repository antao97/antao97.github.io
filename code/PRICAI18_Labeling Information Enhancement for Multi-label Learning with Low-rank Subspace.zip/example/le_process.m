function [ Z ] = le_process()
%UNTITLED4 ????????????????????????
%   ????????????????
load dt.mat;
iter=0;
iter_total=0;
step_size=0;
disp('Start iteration');
disp('Iteration_total      Iteration        f            Step')
for i=miu
    fprintf('miu   %5.5f\n',i);
    iter=0;
    while(iter==0||iter==1||step_size>Step)%not converged
        Z_0=Z;%restore present Z matrix
        gZ=zeros(size(Z));
        gZ(1:size(train_Y,1),:)=lenda*(-train_Y./(1+exp(train_Y.*Z(1:size(train_Y,1),:))))/(size(train_Y,1)*size(train_Y,2));
        gZ(size(train_Y,1)+1:size(train_Y,1)+size(train_X,1)-1,:)=(Z_0(size(train_Y,1)+1:size(train_Y,1)+size(train_X,1)-1,:)-train_X(1:size(train_X,1)-1,:))/((size(train_X,1)-1)*size(train_X,2));
        A=Z-tauZ*gZ;
        [U,S,V]=svd(A);
        S=max(S-tauZ*i,zeros(size(S)));
        Z=U*S*V';
        Z(size(train_Y,1)+size(train_X,1),:)=UnitMatrix;
%        Z(size(train_Y,1)+1:size(train_Y,1)+size(train_X,1),:)=train_X;
        if iter~=0
            f_0=f;
            f=i*sum(sum(S))+lenda*sum(sum(log(1+exp(-train_Y.*Z(1:size(train_Y,1),:)))))/(size(train_Y,1)*size(train_Y,2))+sum(sum((Z_0(size(train_Y,1)+1:size(train_Y,1)+size(train_X,1)-1,:)-train_X(1:size(train_X,1)-1,:)).^2))/(2*(size(train_X,1)-1)*size(train_X,2));
            step_size=abs(f-f_0);
        else
            f=i*sum(sum(S))+lenda*sum(sum(log(1+exp(-train_Y.*Z(1:size(train_Y,1),:)))))/(size(train_Y,1)*size(train_Y,2))+sum(sum((Z_0(size(train_Y,1)+1:size(train_Y,1)+size(train_X,1)-1,:)-train_X(1:size(train_X,1)-1,:)).^2))/(2*(size(train_X,1)-1)*size(train_X,2));
        end
        iter=iter+1;
        iter_total=iter_total+1;
        fprintf('  %5.0f            %5.0f           %5.5f        %5.5f\n',iter_total,iter,f,step_size);
    end
end
disp('End iteration');
end

