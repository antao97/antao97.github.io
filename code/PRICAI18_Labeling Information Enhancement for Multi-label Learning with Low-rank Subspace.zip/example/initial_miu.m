function [ miu ] = initial_miu( eta,Z )
%UNTITLED7 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
miu_last=10^(-5);
[U,S,V]=svd(Z);
sigma=max(max(S));
miu_0=sigma*eta;
num=1;
miu=zeros(1,100);
miu(num)=miu_0;
miu_1=max(eta*miu_0,miu_last);
while miu_1~=miu_last
    num=num+1;
    miu(num)=miu_1;
    miu_0=miu_1;
    miu_1=max(eta*miu_0,miu_last);
end
num=num+1;
miu(num)=miu_1;
miu(miu==0)=[];
disp('Finish generation of series of miu');
end

