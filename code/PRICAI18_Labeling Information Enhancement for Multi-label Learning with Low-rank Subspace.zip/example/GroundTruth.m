clc
clear
addpath(genpath(pwd));
% 
% a={'SJAFFE';'Yeast_spoem';'Yeast_spo5';'Yeast_dtt';'Yeast_cold';'Yeast_heat';'Yeast_spo';'Yeast_diau';'Yeast_elu';'Yeast_cdc';'Yeast_alpha';'Movie';'SBU_3DFE';'Natural_Scene';'toyData'};
% beg={'LDLDataSets\'};
% 
% for dataN = 15:15
%     T=strcat(beg(1),a(dataN),'_binary','.mat');
%     load(T{1,1});
%     reslutName = strcat(beg(1),a(dataN),'_groundTruth','.mat');
%     %load(reslutName{1,1});
%     tic;
%     LP_label = Label_Propagation(features,logicalLabel,0.1,0.5);
%     ML_label = ML_enhancement(features,logicalLabel);
%     FCM_label=GNPC(3,features,logicalLabel);
%     KM_label=FSVM(features,logicalLabel);
%     fprintf('Training time :%d %8.7f \n', dataN,toc);
%     
%     save(reslutName{1,1},'LP_label','ML_label','FCM_label','KM_label') ;
% end


a={'CAL500';'emotions';'medical';'llog';'enron';'image';'scene';'yeast';'slashdot';'corel5k';'rcv1subset2'};
beg={'Dataset\'};
%
for dataN = 4:4
    for k=1:1
        T=strcat(beg(1),a(dataN),'\',a(dataN),'_total_',num2str(k),'.mat');
        load(T{1,1});

        %% label enhancement
        trainLabel=train_target';%
        trainLabel(trainLabel==-1)=0;
        tic;
        features = train_data;
        logicalLabel = trainLabel;
        ML_label = ML_enhancement(features,logicalLabel);
       % LP_label = Label_Propagation(features,logicalLabel,0.1,0.5);
        %KM_label=FSVM(features,logicalLabel);
        %FCM_label=GNPC(10,features,logicalLabel);
        fprintf('Training time :%d %d %8.7f \n', dataN,k,toc);
        %ML_label = normalLabel(ML_label);
        enhancementFile2 = strcat(beg(1),a(dataN),'\',a(dataN),'_ML_',num2str(k),'.mat');
        save(enhancementFile2{1,1},'ML_label','train_data') ;


    end
end
