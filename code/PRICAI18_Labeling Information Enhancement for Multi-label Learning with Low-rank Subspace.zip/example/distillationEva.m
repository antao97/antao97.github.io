clc
clear
addpath(genpath(pwd));
a={'SJAFFE';'Yeast_spoem';'Yeast_spo5';'Yeast_dtt';'Yeast_cold';'Yeast_heat';'Yeast_spo';'Yeast_diau';'Yeast_elu';'Yeast_cdc';'Yeast_alpha';'Movie';'SBU_3DFE';'Natural_Scene';'Human_Gene'};
beg={'LDLDataSets\'};
for dataN = 12:14
    for pa = 3:6
        T = strcat(beg(1),a(dataN),'_distillation_L4_',num2str(pa),'.mat');
        load(T{1,1});
        T=strcat(beg(1),a(dataN),'.mat');
        load(T{1,1});
        DiLabel = normalLabel(modLabel(:,1:size(modLabel,2) - 1));
        
        Cheb = chebyshev(DiLabel,labels);
        Clark = clark(DiLabel,labels);
        Can = canberra(DiLabel,labels);
        KL = kldist(DiLabel,labels);
        Cosine = cosine(DiLabel,labels);
        Inters = intersection(DiLabel,labels);
        EvaResult = [ Cheb,Clark,Can,KL,Cosine,Inters];
        
        enhancementFile = strcat(beg(1),a(dataN),'_distillation_L4_',num2str(pa),'.mat');
        save(enhancementFile{1,1},'modLabel','DiLabel','EvaResult','paraL4') ;
        fprintf('times of LE %8.7f \n', dataN);
        %%
    end
end