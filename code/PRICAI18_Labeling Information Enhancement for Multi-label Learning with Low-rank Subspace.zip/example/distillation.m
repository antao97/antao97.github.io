clc
clear
addpath(genpath(pwd));
a={'SJAFFE';'Yeast_spoem';'Yeast_spo5';'Yeast_dtt';'Yeast_cold';'Yeast_heat';'Yeast_spo';'Yeast_diau';'Yeast_elu';'Yeast_cdc';'Yeast_alpha';'Movie';'SBU_3DFE';'Natural_Scene';'toyData'};
beg={'LDLDataSets\'};
Para = {0.01,0.1,1,5,10,50};
for dataN = 15:15
    for pa = 5:5
        T=strcat(beg(1),a(dataN),'_binary.mat');
        load(T{1,1});
        T=strcat(beg(1),a(dataN),'.mat');
        load(T{1,1});
        paraL4 = Para{pa};

        
        %%%%%%%linear model,kernel method%%%%%%%%
        para.ker  = 'rbf'; %type of kernel function ('lin', 'poly', 'rbf', 'sam')
        para.par  = 1*mean(pdist(features)); %parameter of kernel function
        H = kernelmatrix(para.ker, para.par, features, features);% build the kernel matrix on the labeled samples (N x N)
        UnitMatrix = ones(size(features,1),1);
        trainFeature = [H,UnitMatrix];
        %%%%%%%linear model,kernel method%%%%%%%%
        
        trainLabel=logicalLabel;%
        item=rand(size(trainFeature,2),size(trainLabel,2));
        
        trainLabel = [trainLabel,0.5*UnitMatrix];
        item = [item,ones(size(item,1),1)];
        
        

        tic;
        sigma = 1;
        W =  exp(-(L2_distance(trainFeature', trainFeature').^2) / (2 * sigma ^ 2));
        W(W < 0.00001) = 0;
        save dt.mat trainFeature trainLabel W paraL4
        [weights,fval] = fminlbfgs(@LEbfgsProcess,item);
        fprintf('Training time of BFGS-LLD: %8.7f \n', toc);
        

        modLabel = trainFeature * weights;
        DiLabel = normalLabel(modLabel(:,1:size(modLabel,2) - 1));
        
        Cheb = chebyshev(DiLabel,labels);
        Clark = clark(DiLabel,labels);
        Can = canberra(DiLabel,labels);
        KL = kldist(DiLabel,labels);
        Cosine = cosine(DiLabel,labels);
        Inters = intersection(DiLabel,labels);
        EvaResult = [ Cheb,Clark,Can,KL,Cosine,Inters];
        
        enhancementFile = strcat(beg(1),a(dataN),'_distillation_L4_',num2str(pa),'.mat');
        save(enhancementFile{1,1},'modLabel','DiLabel','EvaResult','paraL4') ;
        fprintf('times of LE %8.7f \n', dataN);
    end
end