clc
clear
addpath(genpath(pwd));
a={'SJAFFE';'Yeast_spoem';'Yeast_spo5';'Yeast_dtt';'Yeast_cold';'Yeast_heat';'Yeast_spo';'Yeast_diau';'Yeast_elu';'Yeast_cdc';'Yeast_alpha';'Movie';'SBU_3DFE';'Natural_Scene';'Human_Gene'};
beg={'LDLDataSets\'};

% for pa = 3:6
%     ChebT = [];
%     ClarkT = [];
%     CanT = [];
%     KLT = [];
%     CosineT = [];
%     IntersT = [];
%     for dataN = 4:14
%         
%         
%         T = strcat(beg(1),a(dataN),'_distillation_L4_',num2str(pa),'.mat');
%         load(T{1,1});
%         T=strcat(beg(1),a(dataN),'.mat');
%         load(T{1,1});
%         DiLabel = normalLabel(modLabel(:,1:size(modLabel,2) - 1));
%         
%         Cheb1 = chebyshev(DiLabel,labels);
%         Clark1 = clark(DiLabel,labels);
%         Can1 = canberra(DiLabel,labels);
%         KL1 = kldist(DiLabel,labels);
%         Cosine1 = cosine(DiLabel,labels);
%         Inters1 = intersection(DiLabel,labels);
%         
%         T=strcat(beg(1),a(dataN),'_groundTruth_LDreslut.mat');
%         load(T{1,1});
%         ChebT = [ChebT;Cheb1,Cheb];
%         ClarkT = [ClarkT;Clark1,Clark];
%         CanT = [CanT;Can1,Can];
%         KLT = [KLT;KL1,KL];
%         CosineT = [CosineT;Cosine1,Cosine];
%         IntersT = [IntersT;Inters1,Inters];
%         fprintf('times of LE %8.7f \n', dataN);
%         %%
%     end
%     T=strcat(beg(1),'groundTruth_LDreslut_',num2str(pa),'.mat');
%     save(T{1,1},'ChebT','ClarkT','CanT','KLT','CosineT','IntersT');
% end
    ChebT = [];
    ClarkT = [];
    CanT = [];
    KLT = [];
    CosineT = [];
    IntersT = [];
    for dataN = 1:3
        
        
        
        T=strcat(beg(1),a(dataN),'_groundTruth_LDreslut.mat');
        load(T{1,1});
        ChebT = [ChebT;Cheb];
        ClarkT = [ClarkT;Clark];
        CanT = [CanT;Can];
        KLT = [KLT;KL];
        CosineT = [CosineT;Cosine];
        IntersT = [IntersT;Inters];
        fprintf('times of LE %8.7f \n', dataN);
        %%
    end
    T=strcat(beg(1),'groundTruth_LDreslut','.mat');
    save(T{1,1},'ChebT','ClarkT','CanT','KLT','CosineT','IntersT');
