clc
clear
addpath(genpath(pwd));
a={'SJAFFE';'Yeast_spoem';'Yeast_spo5';'Yeast_dtt';'Yeast_cold';'Yeast_heat';'Yeast_spo';'Yeast_diau';'Yeast_elu';'Yeast_cdc';'Yeast_alpha';'Movie';'SBU_3DFE';'Natural_Scene';'toyData'};
beg={'LDLDataSets\'};
pa = [2,3,5,5,5,5,5,5,5,5,5,3,5,1,5];
GroupSimT=[];
EntropyT=[];
rankingLossT=[];
for dataN = 15:15


    tic;
    T=strcat(beg(1),a(dataN),'_binary.mat');
    load(T{1,1});
    T=strcat(beg(1),a(dataN),'_groundTruth','.mat');
    load(T{1,1});
    T=strcat(beg(1),a(dataN),'_distillation_L4_',num2str(pa(dataN)),'.mat');
    load(T{1,1});
    train_data = features;
    train_target = logicalLabel';
    [size_sam,size_X]=size(train_data);
    kNN = round(size_sam / 40) + 1 ;



    %GroupSim  = [GraphEvaluate( train_data,train_target',DiLabel,kNN ),GraphEvaluate( train_data,train_target',LP_label,kNN ),GraphEvaluate( train_data,train_target',ML_label,kNN ),GraphEvaluate( train_data,train_target',FCM_label,kNN ),GraphEvaluate( train_data,train_target',KM_label,kNN )];
    Entropy = [EntropyEvaluate(DiLabel),EntropyEvaluate(LP_label),EntropyEvaluate(ML_label),EntropyEvaluate(FCM_label),EntropyEvaluate(KM_label)];
    %rankingLoss = [RankingLoss(DiLabel',train_target),RankingLoss(LP_label',train_target),RankingLoss(ML_label',train_target),RankingLoss(FCM_label',train_target),RankingLoss(KM_label',train_target)];
    fprintf(' time of:%d %f \n', dataN,toc);
     GroupSim  = GraphEvaluate( train_data,train_target',DiLabel,kNN );
    %GroupSimT=[GroupSimT;GroupSim];
    EntropyT=[EntropyT;Entropy];
   % rankingLossT=[rankingLossT;rankingLoss];


end
% T=strcat(beg(1),'toy_Data_SpecialMeansures','.mat');
% save(T{1,1},'GroupSim','Entropy','rankingLoss') ;


% %datasets={'CAL500';'emotions';'medical';'llog';'enron';'image';'scene';'yeast';'slashdot';'corel5k';'rcv1subset2'};
% beg={'Dataset\'};
% GroupSimT=[];
% EntropyT=[];
% rankingLossT=[];
% for dataN = 1:5
%     for k=1:4
%         
%         tic;
%         T=strcat(beg(1),datasets(dataN),'\',datasets(dataN),'_total_',num2str(1),'.mat');
%         load(T{1,1});
%         T=strcat(beg(1),datasets(dataN),'\',datasets(dataN),'_FCM_',num2str(1),'.mat');
%         load(T{1,1});
%         T=strcat(beg(1),datasets(dataN),'\',datasets(dataN),'_KM_',num2str(1),'.mat');
%         load(T{1,1});
%         T=strcat(beg(1),datasets(dataN),'\',datasets(dataN),'_LP_',num2str(1),'.mat');
%         load(T{1,1});
%         T=strcat(beg(1),datasets(dataN),'\',datasets(dataN),'_ML_',num2str(1),'.mat');
%         load(T{1,1});
%         DistillationFile = strcat(beg(1),datasets(dataN),'\',datasets(dataN),'_enhancement_',num2str(k),'.mat');
%         load(DistillationFile{1,1}) ;
%         
%         
%         [size_sam,size_X]=size(train_data);
%         kNN = round(size_sam / 40) + 1 ;
%         ML_label = normalLabel(ML_label);
%         KM_label = normalLabel(KM_label);
%         %             GroupSim  =   [GraphEvaluate( train_data,train_target',DiLabel,kNN ),GraphEvaluate( train_data,train_target',LP_label,kNN ),GraphEvaluate( train_data,train_target',ML_label,kNN ),GraphEvaluate( train_data,train_target',FCM_label,kNN ),GraphEvaluate( train_data,train_target',KM_label,kNN )];
%        % Entropy =  [EntropyEvaluate(DiLabel),EntropyEvaluate(LP_label),EntropyEvaluate(ML_label),EntropyEvaluate(FCM_label),EntropyEvaluate(KM_label)];
%         %             rankingLoss =  [RankingLoss(DiLabel',train_target),RankingLoss(LP_label',train_target),RankingLoss(ML_label',train_target),RankingLoss(FCM_label',train_target),RankingLoss(KM_label',train_target)];
%         % GroupSim  =   GraphEvaluate( train_data,train_target',DiLabel,kNN );
%         
%         fprintf(' time of:%d %d %8.7f \n', dataN,k,toc);
%         GroupSim  =   GraphEvaluate( train_data,train_target',DiLabel,kNN );
%         Entropy =  EntropyEvaluate(DiLabel),EntropyEvaluate(LP_label);
%         %GroupSimT=[GroupSimT;GroupSim];
%         %EntropyT=[EntropyT;Entropy];
%         %rankingLossT=[rankingLossT;rankingLoss];
%     end
%     
% end


