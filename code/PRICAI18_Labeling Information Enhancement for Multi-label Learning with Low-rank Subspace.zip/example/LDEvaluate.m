clc
clear
addpath(genpath(pwd));
a={'SJAFFE';'Yeast_spoem';'Yeast_spo5';'Yeast_dtt';'Yeast_cold';'Yeast_heat';'Yeast_spo';'Yeast_diau';'Yeast_elu';'Yeast_cdc';'Yeast_alpha';'Movie';'SBU_3DFE';'Natural_Scene';'toyData'};
beg={'LDLDataSets\'};
for dataN = 15:15
    T=strcat(beg(1),a(dataN),'.mat');
    load(T{1,1});
    T=strcat(beg(1),a(dataN),'_groundTruth.mat');
    load(T{1,1});
    ML_label = normalLabel(ML_label);
    KM_label = normalLabel(KM_label);
    Cheb = [chebyshev(LP_label,labels),chebyshev(ML_label,labels),chebyshev(FCM_label,labels),chebyshev(KM_label,labels)];
    Clark = [clark(LP_label,labels),clark(ML_label,labels),clark(FCM_label,labels),clark(KM_label,labels)];
    Can = [canberra(LP_label,labels),canberra(ML_label,labels),canberra(FCM_label,labels),canberra(KM_label,labels)];
    KL = [kldist(LP_label,labels),kldist(ML_label,labels),kldist(FCM_label,labels),kldist(KM_label,labels)];
    Cosine = [cosine(LP_label,labels),cosine(ML_label,labels),cosine(FCM_label,labels),cosine(KM_label,labels)];
    Inters = [intersection(LP_label,labels),intersection(ML_label,labels),intersection(FCM_label,labels),intersection(KM_label,labels)];
    T=strcat(beg(1),a(dataN),'_groundTruth_LDreslut.mat');
    save(T{1,1},'Cheb','Clark','Can','KL','Cosine','Inters');
end