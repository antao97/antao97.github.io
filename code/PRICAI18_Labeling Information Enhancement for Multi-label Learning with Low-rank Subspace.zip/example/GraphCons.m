function  edge  = GraphCons( feature,label,k,alp )
%GRAPHCONS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[size_sam,size_X]=size(feature);

order = [1:size_sam]';
edge = [];
for i = 1: size_sam
    SumDist = sum(((feature - repmat(feature(i,:),[size_sam,1])).^2),2)*(1-alp) + alp * sum(((label - repmat(label(i,:),[size_sam,1])).^2),2);
    SumDistOrder = [SumDist,order];
    ranked = sortrows(SumDistOrder);
    edge = [edge;[i*ones(k-1,1),ranked(2:k,2),ones(k-1,1)]];
end
end

