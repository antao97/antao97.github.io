clc
clear
addpath(genpath(pwd));
beg={'LDLDataSets\'};
[ x,d ] = ToyDataset(  );
features = x';
labelDistribution = d;
logicalLabel = binaryzation(labelDistribution,0.5);
reslutName = strcat(beg(1),'toyData_binary','.mat');
save(reslutName{1,1},'features','labelDistribution','logicalLabel') ;
reslutName = strcat(beg(1),'toyData','.mat');
labels = d;
save(reslutName{1,1},'features','labels') ;