clc
clear
addpath(genpath(pwd));
a={'CAL500'};
beg={'Dataset\'};
T=strcat(beg(1),a(1),'\',a(1),'_total_',num2str(1),'.mat');
load(T{1,1});
enhancementFile = strcat(beg(1),a(1),'\',a(1),'_enhancement_',num2str(1),'.mat');
load(enhancementFile{1,1}) ;
[size_sam,size_X]=size(train_data);
kNN = round(size_sam / 10) + 1 ;
GroupSim  = GraphEvaluate( train_data,train_target',modLabel,kNN )

aaa = EntropyEvaluate(modLabel);
bb = EntropyEvaluate(train_target');