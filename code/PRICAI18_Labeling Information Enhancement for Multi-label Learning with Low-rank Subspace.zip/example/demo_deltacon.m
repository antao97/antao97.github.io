clc
clear
[sim, simSTD, time, timeSTD] = DeltaCon('edge', 'naive', 'GRAPHS/2.txt', 'GRAPHS/1.txt', 0.1)
%[sim, simSTD, time, timeSTD] = DeltaCon('edge', 'fast', 'GRAPHS/rKron5_1.txt', 'GRAPHS/rKron5_1.txt', 0.1)
