trainFeature = [1,2;4,7;3,4;5,9];
%modProb = [1,1,0;1,0,1;1,1,1;0,0,1];
weight = [1,1,1;1,1,1];
modProb = trainFeature*weight;
sigma = 1;
W =  exp(-(L2_distance(trainFeature', trainFeature').^2) / (2 * sigma ^ 2));
D = diag(sum(W,2));
L = D - W;
L4 = sum(sum(W.* ( L2_distance(modProb',modProb').^2 )))/2;
gradL4= zeros(2,3);
for i = 1:2
    for j = 1:3
       gradL4(i,j) =sum(sum( W.* (bsxfun(@minus,trainFeature(:,i),trainFeature(:,i)')).*(bsxfun(@minus,modProb(:,j),modProb(:,j)'))));
    end
end
L5 = trace(modProb'*L*modProb);
gradL5 = trainFeature'*L*trainFeature*weight + ( trainFeature'*L*trainFeature)'*weight;