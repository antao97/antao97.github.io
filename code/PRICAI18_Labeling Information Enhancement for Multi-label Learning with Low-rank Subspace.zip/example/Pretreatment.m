a={'SJAFFE';'Yeast_spoem';'Yeast_spo5';'Yeast_dtt';'Yeast_cold';'Yeast_heat';'Yeast_spo';'Yeast_diau';'Yeast_elu';'Yeast_cdc';'Yeast_alpha';'Movie';'SBU_3DFE';'Natural_Scene';'Human_Gene'};
beg={'LDLDataSets\'};

for dataN = 1:15
    T=strcat(beg(1),a(dataN),'.mat');
    load(T{1,1});
    labelDistribution = labels;
    logicalLabel = binaryzation(labels,0.5);
    reslutName = strcat(beg(1),a(dataN),'_binary','.mat');
    save(reslutName{1,1},'features','labelDistribution','logicalLabel') ;
end
